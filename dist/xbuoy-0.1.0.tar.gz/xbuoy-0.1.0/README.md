# xbuoy

A package to aggregate buoy data into xarray objects

## Installation

```bash
$ pip install xbuoy
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`xbuoy` was created by Anthony Meza. It is licensed under the terms of the MIT license.

## Credits

`xbuoy` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
