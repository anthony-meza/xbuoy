# xbuoy

A package to aggregate buoy data into xarray objects

## Installation

```bash
$ pip install xbuoy
```

## Usage

- TODO


## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`xbuoy` was created by Anthony Meza. It is licensed under the terms of the MIT license.

## Credits Development

`xbuoy` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).

Setting up came from the [`pypkg`](https://py-pkgs.org/03-how-to-package-a-python.html) instructions and poetry. 

If developing, use poetry. To initialize poetry, use `poetry install` in the root. Then add dependencies using `poetry add`. Finally, you can test build this using `poetry build`. Finally, the package can be installed into a conda enviornment using `pip install ./dist/xbuoy-X.X.X-py3-none-any.whl`
